## Chinook Database - Versions 1.1 to 1.3 (Current Release)

![](Chinook_Schema_http://lh4.ggpht.com/_oKo6zFhdD98/SWFPtyfHJFI/AAAAAAAAAMc/GdrlzeBNsZM/s800/ChinookDatabaseSchema1.1.png)

## Chinook Database - Version 1.0

![](Chinook_Schema_http://lh3.ggpht.com/lerocha/SKeLCLg3OMI/AAAAAAAAAHk/xSzuXETcxeA/s800/ChinookSchema.PNG)