# Information
* [Chinook Database - Data Model](Chinook_Schema)
# Installation
* [How do I create the Chinook Database?](Create_Databases)
# Customization
* [Generating SQL scripts for the Chinook Database](Building_Scripts)